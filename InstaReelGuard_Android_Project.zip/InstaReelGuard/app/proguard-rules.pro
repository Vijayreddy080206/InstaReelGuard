# Keep AccessibilityService entry point intact during R8 minification
-keep class com.instaguard.reelblocker.ReelBlockerAccessibilityService { *; }
-keep class com.instaguard.reelblocker.MainActivity { *; }

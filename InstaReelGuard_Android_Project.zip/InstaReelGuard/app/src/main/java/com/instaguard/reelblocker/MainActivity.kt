package com.instaguard.reelblocker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Main control dashboard for InstaReelGuard.
 *
 * Provides:
 * - Real-time Accessibility Service status verification
 * - One-tap button to open Android Accessibility Settings
 * - Instant rule toggles backed by local SharedPreferences
 * - Explicit verification of zero internet permissions
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusBadgeText: TextView
    private lateinit var statusSubtitleText: TextView
    private lateinit var openSettingsButton: Button

    private lateinit var switchMasterEnabled: Switch
    private lateinit var switchRedirectReelsToDm: Switch
    private lateinit var switchAllowSingleDmReel: Switch
    private lateinit var switchAllowSingleHomeReel: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(ReelBlockerAccessibilityService.PREFS_NAME, Context.MODE_PRIVATE)

        statusBadgeText = findViewById(R.id.tv_service_status_badge)
        statusSubtitleText = findViewById(R.id.tv_service_status_subtitle)
        openSettingsButton = findViewById(R.id.btn_open_accessibility_settings)

        switchMasterEnabled = findViewById(R.id.switch_master_enabled)
        switchRedirectReelsToDm = findViewById(R.id.switch_redirect_reels_to_dm)
        switchAllowSingleDmReel = findViewById(R.id.switch_allow_single_dm_reel)
        switchAllowSingleHomeReel = findViewById(R.id.switch_allow_single_home_reel)

        // Load saved preferences (all core rules enabled by default)
        switchMasterEnabled.isChecked = prefs.getBoolean(
            ReelBlockerAccessibilityService.KEY_MASTER_ENABLED, true
        )
        switchRedirectReelsToDm.isChecked = prefs.getBoolean(
            ReelBlockerAccessibilityService.KEY_REDIRECT_REELS_TAB_TO_DM, true
        )
        switchAllowSingleDmReel.isChecked = prefs.getBoolean(
            ReelBlockerAccessibilityService.KEY_ALLOW_SINGLE_DM_REEL, true
        )
        switchAllowSingleHomeReel.isChecked = prefs.getBoolean(
            ReelBlockerAccessibilityService.KEY_ALLOW_SINGLE_HOME_REEL, true
        )

        // Bind listeners
        switchMasterEnabled.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(ReelBlockerAccessibilityService.KEY_MASTER_ENABLED, isChecked).apply()
            refreshServiceStatusUi()
        }

        switchRedirectReelsToDm.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(ReelBlockerAccessibilityService.KEY_REDIRECT_REELS_TAB_TO_DM, isChecked).apply()
        }

        switchAllowSingleDmReel.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(ReelBlockerAccessibilityService.KEY_ALLOW_SINGLE_DM_REEL, isChecked).apply()
        }

        switchAllowSingleHomeReel.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(ReelBlockerAccessibilityService.KEY_ALLOW_SINGLE_HOME_REEL, isChecked).apply()
        }

        openSettingsButton.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshServiceStatusUi()
    }

    private fun refreshServiceStatusUi() {
        val serviceEnabled = isAccessibilityServiceEnabled()
        val masterOn = prefs.getBoolean(ReelBlockerAccessibilityService.KEY_MASTER_ENABLED, true)

        when {
            !serviceEnabled -> {
                statusBadgeText.text = "ACTION REQUIRED: SERVICE OFF"
                statusBadgeText.setTextColor(Color.parseColor("#FFB4AB"))
                statusSubtitleText.text =
                    "Tap the button below -> Installed Apps -> InstaReelGuard -> Turn ON."
                openSettingsButton.text = "Enable in Accessibility Settings"
            }
            !masterOn -> {
                statusBadgeText.text = "PAUSED BY USER"
                statusBadgeText.setTextColor(Color.parseColor("#FFD580"))
                statusSubtitleText.text =
                    "Accessibility Service is connected, but Master Protection is switched off."
                openSettingsButton.text = "Manage Accessibility Settings"
            }
            else -> {
                statusBadgeText.text = "ACTIVE & PROTECTING INSTAGRAM"
                statusBadgeText.setTextColor(Color.parseColor("#6DD58C"))
                statusSubtitleText.text =
                    "100% Local On-Device Engine • Zero Internet Permission • Zero Data Leaks"
                openSettingsButton.text = "Open Accessibility Settings"
            }
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        if (ReelBlockerAccessibilityService.isServiceCurrentlyRunning) return true
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val expectedComponent = "$packageName/${ReelBlockerAccessibilityService::class.java.name}"
        val expectedShortComponent = "$packageName/.${ReelBlockerAccessibilityService::class.java.simpleName}"
        return enabledServices.any { info ->
            val id = info.id ?: ""
            id.equals(expectedComponent, ignoreCase = true) ||
            id.equals(expectedShortComponent, ignoreCase = true)
        }
    }
}

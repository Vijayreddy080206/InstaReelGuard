package com.instaguard.reelblocker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque

/**
 * InstaReelGuard — Production-Grade Local Accessibility Service for Android.
 *
 * Security & Privacy Architecture:
 * - Zero network access (no INTERNET permission in AndroidManifest.xml).
 * - Strictly scoped to package "com.instagram.android" at both the OS XML config level
 *   and runtime event filter level. Other apps and Android system UI are never inspected.
 * - Zero disk logging or storage of screen text, messages, or usernames.
 * - Bounded BFS node traversal (max 90 nodes) with event throttling for 120Hz smoothness.
 *
 * Behavioral Rules Enforced:
 * 1. Reels Tab Block & DM Redirect:
 *    Tapping the Reels button on the bottom navigation bar immediately redirects the user
 *    to the Direct Messages (DM) section (clicks Home tab -> clicks top-right DM inbox button).
 * 2. DM Shared Reels (Watch Specific Reel, Block Scrolling to 2nd Reel):
 *    When a user taps any shared Reel inside a friend's DM chat (whether 1, 3, 4, or 10 separate
 *    Reels sent in the chat), that opened Reel plays normally. The instant the user swipes/scrolls
 *    vertically to load a 2nd Reel inside the player, the service triggers GLOBAL_ACTION_BACK,
 *    returning the user directly into that exact friend's DM chat.
 * 3. Home Feed Reels (Watch Specific Opened Reel, Block Scrolling to 2nd Reel):
 *    When a user taps a Reel on the Home feed to open it in the full-screen Reel viewer, that
 *    specific Reel plays normally. Scrolling to a 2nd Reel immediately triggers GLOBAL_ACTION_BACK,
 *    returning the user to their exact spot on the Home feed.
 * 4. Normal Instagram Features Untouched:
 *    Stories, normal photo/carousel posts, Home feed inline scrolling, Explore grid, Profile,
 *    and DM conversations operate without interruption.
 */
class ReelBlockerAccessibilityService : AccessibilityService() {

    companion object {
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"

        // SharedPreferences keys
        const val PREFS_NAME = "instaguard_prefs"
        const val KEY_MASTER_ENABLED = "master_enabled"
        const val KEY_REDIRECT_REELS_TAB_TO_DM = "redirect_reels_tab_to_dm"
        const val KEY_ALLOW_SINGLE_DM_REEL = "allow_single_dm_reel"
        const val KEY_ALLOW_SINGLE_HOME_REEL = "allow_single_home_reel"

        // Instagram Bottom Navigation Bar IDs
        private val REELS_TAB_IDS = setOf(
            "com.instagram.android:id/clips_tab"
        )
        private val HOME_TAB_IDS = setOf(
            "com.instagram.android:id/feed_tab"
        )

        // Top-Right Direct / Messenger Inbox Button IDs on Home Screen
        private val DM_BUTTON_IDS = setOf(
            "com.instagram.android:id/action_bar_inbox_button",
            "com.instagram.android:id/direct_tab",
            "com.instagram.android:id/action_bar_wrapper_inbox_button"
        )

        // DM Chat Thread & DM Inbox Screen Indicators
        private val DM_SCREEN_INDICATOR_IDS = setOf(
            "com.instagram.android:id/row_thread_composer_edittext",
            "com.instagram.android:id/row_thread_composer_button_send",
            "com.instagram.android:id/direct_thread_content_below_action_bar",
            "com.instagram.android:id/message_list",
            "com.instagram.android:id/thread_list_recyclerview",
            "com.instagram.android:id/direct_inbox_recycler_view"
        )

        // Full-Screen Reels Player (ClipsViewer) Root & Pager IDs
        private val CLIPS_FULLSCREEN_PAGER_IDS = setOf(
            "com.instagram.android:id/clips_viewer_view_pager",
            "com.instagram.android:id/clips_viewer_root"
        )

        // Story Viewer IDs (Explicitly whitelisted so Stories are NEVER blocked)
        private val STORY_VIEWER_IDS = setOf(
            "com.instagram.android:id/reel_viewer_root",
            "com.instagram.android:id/reel_viewer_image_view",
            "com.instagram.android:id/story_viewer_container"
        )

        // Non-Reel scrollable containers (Comments, Share Sheet, Messages, Stories Tray)
        private val SAFE_SCROLL_CONTAINER_HINTS = listOf(
            "comment",
            "message_list",
            "thread_list",
            "direct_inbox",
            "tray_recycler_view",
            "bottom_sheet",
            "share_sheet"
        )

        // Timing & performance constants (in milliseconds)
        private const val EVENT_THROTTLE_MS = 85L
        private const val ACTION_COOLDOWN_MS = 550L
        private const val INITIAL_REEL_SETTLE_GRACE_MS = 450L
        private const val ALLOWED_TAP_WINDOW_MS = 2800L
        private const val DM_REDIRECT_TIMEOUT_MS = 1600L
        private const val MAX_BFS_NODES = 90

        @Volatile
        var isServiceCurrentlyRunning: Boolean = false
            private set
    }

    private enum class ScreenOrigin {
        HOME_FEED,
        DM_CHAT_OR_INBOX,
        OTHER
    }

    private lateinit var prefs: SharedPreferences
    private val mainHandler = Handler(Looper.getMainLooper())

    // Navigation & Single-Reel session state
    private var lastOrigin: ScreenOrigin = ScreenOrigin.HOME_FEED
    private var inSingleReelSession: Boolean = false
    private var singleReelOpenedAtMs: Long = 0L
    private var initialReelSignature: String? = null
    private var initialPagerIndex: Int = -1

    // Tracks when the user taps a Reel inside a DM chat or on the Home feed
    private var lastAllowedContentTapAtMs: Long = 0L
    private var lastAllowedTapOrigin: ScreenOrigin = ScreenOrigin.HOME_FEED

    // Redirect to DM state
    private var pendingClickDmInbox: Boolean = false
    private var pendingClickDmDeadlineMs: Long = 0L

    // Debounce / throttle timestamps
    private var lastContentCheckAtMs: Long = 0L
    private var lastBlockActionAtMs: Long = 0L

    private val dmClickRetryRunnable = Runnable {
        val now = SystemClock.elapsedRealtime()
        if (pendingClickDmInbox && now < pendingClickDmDeadlineMs) {
            val root = rootInActiveWindow ?: return@Runnable
            if (tryClickDmButton(root)) {
                pendingClickDmInbox = false
                lastOrigin = ScreenOrigin.DM_CHAT_OR_INBOX
            }
        } else {
            pendingClickDmInbox = false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceCurrentlyRunning = true
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        serviceInfo = serviceInfo.apply {
            packageNames = arrayOf(INSTAGRAM_PACKAGE)
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED or
                    AccessibilityEvent.TYPE_VIEW_SELECTED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 70L
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Strict package guard: ignore everything outside Instagram
        val pkg = event.packageName?.toString() ?: return
        if (pkg != INSTAGRAM_PACKAGE) return

        if (!prefs.getBoolean(KEY_MASTER_ENABLED, true)) return

        val now = SystemClock.elapsedRealtime()

        // 1. Handle click and selection events (distinguishing bottom Reels tab vs tapping a Reel in DM/Home)
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_SELECTED
        ) {
            if (isEventSourceReelsBottomTab(event)) {
                handleReelsTabBlocked(now)
                return
            } else if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                recordContentTapIfInAllowedOrigin(event, now)
            }
        }

        // 2. Handle scroll events while watching an allowed Single Reel (from DM or Home feed)
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && inSingleReelSession) {
            handleScrollDuringSingleReelSession(event, now)
        }

        // 3. Throttle high-frequency content change events for zero UI lag
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (now - lastContentCheckAtMs < EVENT_THROTTLE_MS) return
            lastContentCheckAtMs = now
        }

        val root = rootInActiveWindow ?: return
        evaluateScreenState(root, now)
    }

    /**
     * Records when the user taps inside the main content area of a DM chat or Home feed,
     * so if that tap opens a Reel (even if Instagram highlights clips_tab in the background),
     * we recognize it as an allowed Single-Reel open rather than a Reels Tab click.
     */
    private fun recordContentTapIfInAllowedOrigin(event: AccessibilityEvent, now: Long) {
        if (lastOrigin != ScreenOrigin.DM_CHAT_OR_INBOX && lastOrigin != ScreenOrigin.HOME_FEED) {
            return
        }
        val src = event.source ?: return
        val rect = Rect()
        src.getBoundsInScreen(rect)
        val screenHeight = resources.displayMetrics.heightPixels

        // Ensure the tap was in the main content area (above the bottom navigation bar)
        if (rect.bottom < (screenHeight * 0.88).toInt()) {
            lastAllowedContentTapAtMs = now
            lastAllowedTapOrigin = lastOrigin
            // Clear any prior block cooldown so rapid opening of consecutive DM Reels always works
            lastBlockActionAtMs = 0L
        }
    }

    /**
     * Evaluates the current Instagram window state and enforces the blocking/redirection rules.
     */
    private fun evaluateScreenState(root: AccessibilityNodeInfo, now: Long) {
        val snapshot = inspectWindowHierarchy(root)

        // Complete pending DM inbox click after switching to Home tab
        if (pendingClickDmInbox) {
            if (now < pendingClickDmDeadlineMs) {
                if (snapshot.dmButtonNode != null && clickNodeOrParent(snapshot.dmButtonNode)) {
                    pendingClickDmInbox = false
                    resetSingleReelSession()
                    lastOrigin = ScreenOrigin.DM_CHAT_OR_INBOX
                    return
                }
            } else {
                pendingClickDmInbox = false
            }
        }

        // Never interfere with Instagram Stories
        if (snapshot.isStoryViewerVisible) {
            return
        }

        // Case A: User is looking at a DM Chat Thread or the DM Inbox (and full-screen Reel player is not covering it)
        if (snapshot.isDmScreenVisible && !snapshot.isClipsViewerVisible) {
            lastOrigin = ScreenOrigin.DM_CHAT_OR_INBOX
            resetSingleReelSession()
            return
        }

        // Case B: Full-Screen Reel Viewer (ClipsViewer) is active
        if (snapshot.isClipsViewerVisible) {
            val allowDmReel = prefs.getBoolean(KEY_ALLOW_SINGLE_DM_REEL, true)
            val allowHomeReel = prefs.getBoolean(KEY_ALLOW_SINGLE_HOME_REEL, true)

            val recentlyTappedFromAllowedOrigin = (now - lastAllowedContentTapAtMs) <= ALLOWED_TAP_WINDOW_MS
            val effectiveOrigin = if (recentlyTappedFromAllowedOrigin) lastAllowedTapOrigin else lastOrigin

            val isAllowedSingleReelOrigin =
                (effectiveOrigin == ScreenOrigin.DM_CHAT_OR_INBOX && allowDmReel) ||
                (effectiveOrigin == ScreenOrigin.HOME_FEED && allowHomeReel)

            // If user opened the Reels tab directly (without tapping a shared DM Reel or Home Reel), block & redirect to DMs
            if (snapshot.isReelsTabSelected && !inSingleReelSession && !recentlyTappedFromAllowedOrigin) {
                handleReelsTabBlocked(now, snapshot)
                return
            }

            if (!isAllowedSingleReelOrigin) {
                triggerBackAction(now)
                return
            }

            if (!inSingleReelSession) {
                // Start a Single-Reel Session for this specific opened Reel
                inSingleReelSession = true
                singleReelOpenedAtMs = now
                initialReelSignature = snapshot.currentReelSignature
                initialPagerIndex = -1
            } else {
                // Already in a Single-Reel Session: check if the Reel signature changed after settle period
                if (now - singleReelOpenedAtMs > INITIAL_REEL_SETTLE_GRACE_MS) {
                    val oldSig = initialReelSignature
                    val newSig = snapshot.currentReelSignature
                    if (oldSig == null && newSig != null) {
                        initialReelSignature = newSig
                    } else if (oldSig != null && newSig != null && oldSig != newSig &&
                        !snapshot.isCommentOrShareSheetOpen
                    ) {
                        // User scrolled to a 2nd Reel -> immediately kick back to DM chat or Home feed
                        resetSingleReelSession()
                        triggerBackAction(now)
                        return
                    }
                }
            }
            return
        }

        // Case C: Bottom Reels Tab is selected (even if ClipsViewer node hasn't finished rendering yet)
        if (snapshot.isReelsTabSelected && !inSingleReelSession) {
            handleReelsTabBlocked(now, snapshot)
            return
        }

        // Case D: User is browsing the Home Feed normally
        if (snapshot.isHomeTabSelected && !snapshot.isClipsViewerVisible) {
            lastOrigin = ScreenOrigin.HOME_FEED
            resetSingleReelSession()
            return
        }

        // Case E: Other normal Instagram screens (Profile, Search/Explore grid, Activity feed)
        if (!snapshot.isClipsViewerVisible) {
            lastOrigin = ScreenOrigin.OTHER
            resetSingleReelSession()
        }
    }

    /**
     * Detects vertical swipes/scrolls inside the Reel player when a user finishes watching
     * a specific Reel opened from a DM or Home feed and tries to scroll to a 2nd Reel.
     */
    private fun handleScrollDuringSingleReelSession(event: AccessibilityEvent, now: Long) {
        val elapsedSinceOpen = now - singleReelOpenedAtMs

        val sourceNode = event.source
        val viewId = sourceNode?.viewIdResourceName?.lowercase() ?: ""
        val className = event.className?.toString()?.lowercase() ?: ""

        // Ignore scrolling inside comments, share sheets, or message lists
        if (SAFE_SCROLL_CONTAINER_HINTS.any { viewId.contains(it) }) {
            return
        }

        val isClipsPagerScroll = viewId.contains("clips_viewer") ||
                viewId.contains("view_pager") ||
                className.contains("viewpager") ||
                className.contains("recyclerview")

        if (!isClipsPagerScroll) return

        val currentIndex = event.fromIndex

        // During the initial 450ms settle window, capture the starting pager index and ignore layout events
        if (elapsedSinceOpen <= INITIAL_REEL_SETTLE_GRACE_MS) {
            if (initialPagerIndex == -1 && currentIndex >= 0) {
                initialPagerIndex = currentIndex
            }
            return
        }

        if (initialPagerIndex == -1 && currentIndex >= 0) {
            initialPagerIndex = currentIndex
        }

        val indexAdvanced = (initialPagerIndex >= 0 && currentIndex >= 0 && currentIndex != initialPagerIndex) ||
                (currentIndex >= 1)

        val scrolledVertically = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            event.scrollDeltaY > 55
        } else {
            event.scrollY > 0
        }

        if (indexAdvanced || scrolledVertically) {
            // Double-check that the comment or share sheet isn't open before kicking back
            val root = rootInActiveWindow
            if (root != null) {
                val snap = inspectWindowHierarchy(root)
                if (snap.isCommentOrShareSheetOpen) return
            }
            resetSingleReelSession()
            triggerBackAction(now)
        }
    }

    /**
     * Blocks the Reels Tab and redirects the user straight to the DM section.
     */
    private fun handleReelsTabBlocked(now: Long, snapshot: WindowSnapshot? = null) {
        if (now - lastBlockActionAtMs < ACTION_COOLDOWN_MS) return
        lastBlockActionAtMs = now
        resetSingleReelSession()
        lastAllowedContentTapAtMs = 0L

        val redirectToDm = prefs.getBoolean(KEY_REDIRECT_REELS_TAB_TO_DM, true)
        val root = rootInActiveWindow

        if (redirectToDm && root != null) {
            val snap = snapshot ?: inspectWindowHierarchy(root)

            // Step 1: If the DM inbox button is already on screen, click it immediately
            if (snap.dmButtonNode != null && clickNodeOrParent(snap.dmButtonNode)) {
                pendingClickDmInbox = false
                lastOrigin = ScreenOrigin.DM_CHAT_OR_INBOX
                return
            }

            // Step 2: Since Instagram hides the top action bar while on the Reels tab,
            // click the Home tab first and schedule an immediate click on the top-right DM icon
            if (snap.homeTabNode != null && clickNodeOrParent(snap.homeTabNode)) {
                pendingClickDmInbox = true
                pendingClickDmDeadlineMs = now + DM_REDIRECT_TIMEOUT_MS
                mainHandler.removeCallbacks(dmClickRetryRunnable)
                mainHandler.postDelayed(dmClickRetryRunnable, 160L)
                mainHandler.postDelayed(dmClickRetryRunnable, 340L)
                return
            }
        }

        // Fallback if bottom bar nodes are hidden: press system Back
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun triggerBackAction(now: Long) {
        if (now - lastBlockActionAtMs < ACTION_COOLDOWN_MS) return
        lastBlockActionAtMs = now
        lastAllowedContentTapAtMs = 0L
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun resetSingleReelSession() {
        inSingleReelSession = false
        singleReelOpenedAtMs = 0L
        initialReelSignature = null
        initialPagerIndex = -1
    }

    private fun isEventSourceReelsBottomTab(event: AccessibilityEvent): Boolean {
        val src = event.source ?: return false
        val id = src.viewIdResourceName ?: ""
        if (id in REELS_TAB_IDS) return true

        val desc = src.contentDescription?.toString()?.trim() ?: ""
        if (desc.equals("Reels", ignoreCase = true)) {
            val bounds = Rect()
            src.getBoundsInScreen(bounds)
            val displayHeight = resources.displayMetrics.heightPixels
            if (bounds.top >= (displayHeight * 0.80).toInt()) {
                return true
            }
        }
        return false
    }

    private fun tryClickDmButton(root: AccessibilityNodeInfo): Boolean {
        val snap = inspectWindowHierarchy(root)
        return snap.dmButtonNode != null && clickNodeOrParent(snap.dmButtonNode)
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 4) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
            depth++
        }
        return false
    }

    private class WindowSnapshot(
        val isReelsTabSelected: Boolean,
        val isHomeTabSelected: Boolean,
        val isDmScreenVisible: Boolean,
        val isClipsViewerVisible: Boolean,
        val isStoryViewerVisible: Boolean,
        val isCommentOrShareSheetOpen: Boolean,
        val homeTabNode: AccessibilityNodeInfo?,
        val dmButtonNode: AccessibilityNodeInfo?,
        val currentReelSignature: String?
    )

    /**
     * Bounded BFS traversal of the active Instagram window hierarchy.
     * Examines at most MAX_BFS_NODES nodes so every check finishes in < 1.5ms.
     */
    private fun inspectWindowHierarchy(root: AccessibilityNodeInfo): WindowSnapshot {
        var isReelsTabSelected = false
        var isHomeTabSelected = false
        var isDmScreenVisible = false
        var isClipsViewerVisible = false
        var isStoryViewerVisible = false
        var isCommentOrShareSheetOpen = false
        var homeTabNode: AccessibilityNodeInfo? = null
        var dmButtonNode: AccessibilityNodeInfo? = null
        var reelAuthorOrCaption: String? = null

        val screenHeight = resources.displayMetrics.heightPixels
        val screenWidth = resources.displayMetrics.widthPixels
        val rect = Rect()

        val queue = ArrayDeque<AccessibilityNodeInfo>(MAX_BFS_NODES)
        queue.add(root)
        var visited = 0

        while (queue.isNotEmpty() && visited < MAX_BFS_NODES) {
            val node = queue.removeFirst()
            visited++

            val viewId = node.viewIdResourceName ?: ""
            val contentDesc = node.contentDescription?.toString()?.trim() ?: ""
            val text = node.text?.toString()?.trim() ?: ""

            // 1. Story Viewer check (Never block Stories)
            if (viewId in STORY_VIEWER_IDS && node.isVisibleToUser) {
                isStoryViewerVisible = true
            }

            // 2. Reels Bottom Tab check
            if (viewId in REELS_TAB_IDS ||
                (contentDesc.equals("Reels", ignoreCase = true) && isBottomBarPosition(node, rect, screenHeight))
            ) {
                if (node.isSelected) {
                    isReelsTabSelected = true
                }
            }

            // 3. Home Bottom Tab check
            if (viewId in HOME_TAB_IDS ||
                (contentDesc.equals("Home", ignoreCase = true) && isBottomBarPosition(node, rect, screenHeight))
            ) {
                if (homeTabNode == null) homeTabNode = node
                if (node.isSelected) {
                    isHomeTabSelected = true
                }
            }

            // 4. Direct / Messenger Top-Right Button check
            if (viewId in DM_BUTTON_IDS ||
                (isTopRightPosition(node, rect, screenWidth, screenHeight) &&
                        (contentDesc.contains("Direct", ignoreCase = true) ||
                         contentDesc.contains("Messenger", ignoreCase = true) ||
                         contentDesc.contains("message", ignoreCase = true)))
            ) {
                if (dmButtonNode == null && node.isVisibleToUser) {
                    dmButtonNode = node
                }
            }

            // 5. DM Chat Thread / DM Inbox check
            if (node.isVisibleToUser &&
                (viewId in DM_SCREEN_INDICATOR_IDS ||
                 viewId.contains("direct_thread", ignoreCase = true) ||
                 viewId.contains("row_thread_composer", ignoreCase = true))
            ) {
                isDmScreenVisible = true
            }

            // 6. Full-Screen ClipsViewer check (verifies full-screen bounds to never confuse with inline feed/chat previews)
            if (node.isVisibleToUser &&
                (viewId in CLIPS_FULLSCREEN_PAGER_IDS || viewId.contains("clips_viewer_view_pager"))
            ) {
                node.getBoundsInScreen(rect)
                if (rect.height() >= (screenHeight * 0.72).toInt()) {
                    isClipsViewerVisible = true
                }
            }

            // 7. Active Reel signature (author username or caption) inside ClipsViewer
            if (reelAuthorOrCaption == null && node.isVisibleToUser) {
                if (viewId.contains("clips_author_username") ||
                    viewId.contains("clips_author_info") ||
                    viewId.contains("clips_caption") ||
                    contentDesc.startsWith("Reel by ", ignoreCase = true)
                ) {
                    val sig = if (text.isNotEmpty()) text else contentDesc
                    if (sig.isNotEmpty()) {
                        reelAuthorOrCaption = sig
                    }
                }
            }

            // 8. Comment Sheet or Share Sheet check
            if (node.isVisibleToUser &&
                (viewId.contains("comment_list") ||
                 viewId.contains("layout_comment_thread") ||
                 viewId.contains("direct_share_sheet"))
            ) {
                isCommentOrShareSheetOpen = true
            }

            val childCount = node.childCount
            for (i in 0 until childCount) {
                if (visited + queue.size >= MAX_BFS_NODES) break
                val child = node.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }

        return WindowSnapshot(
            isReelsTabSelected = isReelsTabSelected,
            isHomeTabSelected = isHomeTabSelected,
            isDmScreenVisible = isDmScreenVisible,
            isClipsViewerVisible = isClipsViewerVisible,
            isStoryViewerVisible = isStoryViewerVisible,
            isCommentOrShareSheetOpen = isCommentOrShareSheetOpen,
            homeTabNode = homeTabNode,
            dmButtonNode = dmButtonNode,
            currentReelSignature = reelAuthorOrCaption
        )
    }

    private fun isBottomBarPosition(node: AccessibilityNodeInfo, rect: Rect, screenHeight: Int): Boolean {
        node.getBoundsInScreen(rect)
        return rect.top >= (screenHeight * 0.80).toInt()
    }

    private fun isTopRightPosition(
        node: AccessibilityNodeInfo,
        rect: Rect,
        screenWidth: Int,
        screenHeight: Int
    ): Boolean {
        node.getBoundsInScreen(rect)
        return rect.bottom <= (screenHeight * 0.18).toInt() && rect.left >= (screenWidth * 0.65).toInt()
    }

    override fun onInterrupt() {
        resetSingleReelSession()
        pendingClickDmInbox = false
        mainHandler.removeCallbacks(dmClickRetryRunnable)
    }

    override fun onDestroy() {
        isServiceCurrentlyRunning = false
        resetSingleReelSession()
        pendingClickDmInbox = false
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
